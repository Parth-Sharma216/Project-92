import React from 'react';
import { View, Text } from 'react-native';

export default class SavedPasswordsScreen extends React.Component {

  render() {
    return (
      <View>
        <Text> SavedPasswordsScreen </Text>
      </View>
    );
  }
}
